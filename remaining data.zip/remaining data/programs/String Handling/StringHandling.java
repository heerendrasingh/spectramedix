
Print duplicate characters in string
1.
Set<Character> uniqueChars = new HashSet<Character>();
Set<Character> repeats = new HashSet<Character>();
for(int i = 0; i < str.length() - 1; i++) {
    if (repeats.contains(str.charAt(i)) || !uniqueChars.add(str.charAt(i)) {
        repeats.add(str.charAt(i));
    }
}

2.
Test a string is palindrom or not
public class PalindromeTest {

	public static void main(String args[]) {
		System.out.println("Is abc palindrom?: " + isPalindromString("abc"));
	}

	public static boolean isPalindromString(String text) {
		String reverse = reverse(text);
		if (text.equals(reverse)) {
			return true;
		}
		return false;
	}

	public static String reverse(String input) {
		if (input == null || input.isEmpty()) {
			return input;
		}
		return input.charAt(input.length() - 1) + reverse(input.substring(0, input.length() - 1)); //here using recursion 
	}
}
3.
Reverse each word of string like input-Heerendra Singh  output- ardnereeH hgniS
public class ReverseWord {
	public static void main(String args[]) {
		String input = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter sentence");
		input = sc.nextLine();
		StringBuilder sb = new StringBuilder();
		String words[] = input.split(" "); //it returns string type of array and placed each string saprated by passing argument.
		//Enhance for loop
		for (String word : words) {
			for (int i = word.length() - 1; i >= 0; i--) {
				sb.append(word.charAt(i));
			}
			sb.append(" ");
		}
		System.out.println(sb.toString());
	}
}

4.
Reverse a string by word like input-Heerendra Pratap Singh  output-Singh Pratap Heerendra 
public class ReverseWords {
	public static void main(String[] args) {
		String s[] = "Heerendra Pratap Singh".split(" ");
		String ans = "";
		//String class contain method of length() and array have a property called length both works similar.
		for (int i = s.length - 1; i >= 0; i--) {
			ans += s[i] + " ";
		}
		System.out.println("Reversed String:");
		System.out.println(ans);
	}
}
5.
5.1 :
Find the 1st non repeated character from the string
public class Programming {
	/* Step 1: get character array and loop through it to build a hash map with char and their count. 
	   Step 2: loop through LinkedHashMap to find an entry with value 1, that's your first non-repeated character,
	   as LinkedHashMap maintains insertion order. */
	public static char getFirstNonRepeatedChar(String str) {
		Map<Character, Integer> counts = new LinkedHashMap<>(str.length());
		for (char c : str.toCharArray()) {
			counts.put(c, counts.containsKey(c) ? counts.get(c) + 1 : 1);
		}
		for (Entry<Character, Integer> entry : counts.entrySet()) {
			if (entry.getValue() == 1) {
				return entry.getKey();
			}
		}
		throw new RuntimeException("didn't find any non repeated Character");
	}

5.2 :

	//we store repeated and non-repeated character separately,at the end of iteration, first element from List is our first non * repeated character from String.
	
	public class FirstNonRepeatingCharacter {
	public static char firstNonRepeatingChar(String word) {
		Set<Character> repeating = new HashSet<>();
		List<Character> nonRepeating = new ArrayList<>();
		for (int i = 0; i < word.length(); i++) {
			char letter = word.charAt(i);
			if (repeating.contains(letter)) {
				continue;     //	when continue execute rest of loop will get skip.
			}
			if (nonRepeating.contains(letter)) {
				nonRepeating.remove((Character) letter);
				repeating.add(letter);
			} else {
				nonRepeating.add(letter);
			}
		}
		return nonRepeating.get(0);
	}
}

5.3 :

public class FirstNonRepeatingCharacter {
	public static char firstNonRepeatedCharacter(String word) {
		HashMap<Character, Integer> scoreboard = new HashMap<>();
		for (int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			if (scoreboard.containsKey(c)) {
				scoreboard.put(c, scoreboard.get(c) + 1);
			} else {
				scoreboard.put(c, 1);
			}
		}
       // since HashMap doesn't maintain order, going through string again.
		for (int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			if (scoreboard.get(c) == 1) {
				return c;
			}
		}
		throw new RuntimeException("Undefined behaviour");
	}
}

6 :Count special character in a string in java

	String str = "one$two$three$four!five@six$";
    int count = str.length() - str.replaceAll("\\$","").length();
    System.out.println("Done:"+ count);
	
7 :Count the repeated word in a string

class CountRepeatedWord { 

static int countOccurences(String str, String word) 
{ 
	String a[] = str.split(" "); 

	int count = 0; 
	for (int i = 0; i < a.length; i++) 
	{ 
	if (word.equals(a[i])) 
		count++; 
	} 
	return count; 
} 

http://www.srimanjavagroup.com/search.htm
http://www.srimanjavagroup.com/thread/new-to-java/4192/what-amp-why.htm
http://www.srimanjavagroup.com/thread/new-to-java/5587/core-java-interview-question.htm
http://www.srimanjavagroup.com/thread/new-to-java/5330/faq-logical-core-java-questions.htm

