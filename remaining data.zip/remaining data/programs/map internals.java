hashcode() and equals() :-

equals() default implementation provided by the JDK is based on memory location � two objects are equal if and only if they are stored in the same memory address means it simply check the object references of two objects to verify their equality.

public class MainClass {
	public static void main(String[] args) {
		Demo object1 = new Demo(10, 20);
		Demo object2 = new Demo(10, 20);
		System.out.println(object1.equals(object2)); //false //reference comparison 
	}
}

class Demo {
	int a, b;
	public Demo(int a, int b) {
		this.a = a;
		this.b = b;
	}
}
-----------------------------------------------------------------------
String class override equals method which compare value of two string objects.

		String s1 = new String("hello");
		String s2 = new String("hello");
		System.out.println(s1 == s2);//false
		System.out.println(s1.equals(s2));//true
		
	//internal working of equals method.	
	  public boolean equals(Object anObject) {  
      if (this == anObject) {  
          return true;  
      } 
	  return false;  
	}  
	
same way integer,float and other wrapper classes implements equals method for content comparison.
-----------------------------------------------------------------------
hashCode() returns an integer representation of the object memory address.
*Some times default implementation is not enough to satisfy business needs.

equals and hashcode implementation:-
case 1:- when no method is overrided.
class Student {
	int rollNo;
	String name;

	Student(int rollNo, String name) {
		this.rollNo = rollNo;
		this.name = name;
	}
	@Override
	public String toString() {
		return "{" + this.rollNo + " : " + this.name + "}";
	}

}
public class MainClass {
	public static void main(String[] args) {
		Student student1 = new Student(10, "amit");
		Student student2 = new Student(10, "amit");
		System.out.println(student1.hashCode());
		System.out.println(student2.hashCode());
		System.out.println(student1.equals(student2)); //compare referance
	}
}
output:-
366712642
1829164700
false
*above output is technically wrong because both objects are same.

case 2:- When equals method is overrided only
@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Student other = (Student) obj;
		if (this.rollNo == other.rollNo) {
			return true;
		}
		return true;
	}
 public class MainClass {
	public static void main(String[] args) {
		Student student1 = new Student(10, "amit");
		Student student2 = new Student(10, "amit");
		System.out.println(student1.hashCode()); //different hashcode
		System.out.println(student2.hashCode()); //different hashcode
		System.out.println(student1.equals(student2)); 
	}
}
output:-
366712642
1829164700
true
Note:- Overriding equals() alone will make your business fail with hashing data structures like: HashSet, HashMap, HashTable ... etc because if two objects are equal,they must have the same hash code.

The implementation of equals() and hashCode() should follow these rules.
*If o1.equals(o2), then o1.hashCode() == o2.hashCode()should always be true.
*If o1.hashCode() == o2.hashCode is true, it doesn�t mean that o1.equals(o2) will be true.

so to solve that issue we override hashcode method.
case 3:- when hashcode is overrided only.
 @Override
	public int hashCode() {
		return this.rollNo;
	}

output:-
10
10
false //equals still comparing original reference of both objects.



Note:- Overriding hashcode() alone doesn't force Java to ignore memory addresses when comparing two objects.
* If two objects have the same hash code, it doesn't mean that they are equal.



case 4:- when both methods are overrided.

class Student {

	int rollNo;
	String name;

	Student(int rollNo, String name) {
		this.rollNo = rollNo;
		this.name = name;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Student other = (Student) obj;
		if (this.rollNo == other.rollNo) {
			return true;
		}
		return true;
	}
	@Override
	public int hashCode() {
		return this.rollNo;
	}
	@Override
	public String toString() {
		return "{" + this.rollNo + " : " + this.name + "}";
	}

}
public class MainClass {
	public static void main(String[] args) {
		Student student1 = new Student(10, "amit");
		Student student2 = new Student(10, "amit");
		System.out.println(student1.hashCode());
		System.out.println(student2.hashCode());
		System.out.println(student1.equals(student2));
	}
}
output:-
10
10
true
so If two objects are equal according to the equals(Object) method, then calling the hashcode() method on each of the two objects must produce the same integer result.

How HashMap works in Java?
HashMap stores key-value pair in Map.Entry static nested class implementation. HashMap works on hashing algorithm and uses hashCode() and equals() method in put and get methods.
When we call put method by passing key-value pair, HashMap uses Key hashCode() with hashing to find out the index to store the key-value pair. The Entry is stored in the LinkedList, so if there are already existing entry, it uses equals() method to check if the passed key already exists, if yes it overwrites the value else it creates a new entry and store this key-value Entry.
When we call get method by passing Key, again it uses the hashCode() to find the index in the array and then use equals() method to find the correct Entry and return it�s value.
In case of a hash collision, then the key with the same hashcode is going to be stored in the same index as each bucket is a node or a linked list.
Inside each bucket, four things are going to be stored as a form of a linked list.They are hashcode, key, value and the next (which hold the address of the next node with the same hashcode).
The other important things to know about HashMap are capacity, load factor, threshold resizing. HashMap initial default capacity is 16 and load factor is 0.75. Threshold is capacity multiplied by load factor and whenever we try to add an entry, if map size is greater than threshold, HashMap rehashes the contents of map into a new array with a larger capacity. The capacity is always power of 2, so if you know that you need to store a large number of key-value pairs, for example in caching data from database, it�s good idea to initialize the HashMap with correct capacity and load factor.

equals and hashcode method implementation with hashmap
case 1:- when no method is override
class Student {
	int rollNo;
	String name;

	Student(int rollNo, String name) {
		this.rollNo = rollNo;
		this.name = name;
	}

	@Override
	public String toString() {
		return "{" + this.rollNo + " : " + this.name + "}";
	}
}
public class MainClass {
	public static void main(String[] args) {
		Student s1 = new Student(1, "Vineet Kumar");
		Student s2 = new Student(1, "Vineet Kumar");

		map.put(s1, "dummy value1");
		map.put(s2, "dummy value2");

		System.out.println(map);
	}
}
output:-
{{1 : Vineet Kumar}=dummy value1, {1 : Vineet Kumar}=dummy value2}
key object will not get update OR duplicate objects will be added which is wrong.
 
case 2:-
 when hashcode is override only.
 @Override
	public int hashCode() {
		return this.rollNo;
	}
output:-
{{1 : Vineet Kumar}=dummy value1, {1 : Vineet Kumar}=dummy value2}
again output will be same.

this time hash code of key objects will be same but both key refrences student1,student2(compare using equals) are different so output is remain same.
case 3:-
when equals method override only then also key object will  not get update due to different hash codes.
case 4:-
when hashcode is overrided and equals method overrided with return false pramanently then also duplicate objects will be added.
case 5:-
when hashcode is overrided and equals method overrided with return true pramanently then duplicate object will not added if hash code will be same and if hash code will be different then duplicate will be added.
case 6:-
when both methods are overrided then only key object will get update means duplicate objects will not be added.







 