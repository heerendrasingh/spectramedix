//must have a public clone method
//clone() should call super.clone() to obtain the cloned object reference
//class must also implement java.lang.Cloneable interface 